package frameworks;

import org.testng.annotations.Test;


import pom.PomClass;

import org.testng.annotations.DataProvider;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class DDTUsingTestNG 
{
	WebDriver driver;
	
	@BeforeTest
		 public void SetUp() 
		  {
			  System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver\\chromedriver.exe");
		      driver = new ChromeDriver();
		      driver.manage().window().maximize();
		      driver.manage().deleteAllCookies();
			  
		  }
	
	@Test(dataProvider = "dp")
	public void f(String email, String pwd) throws Exception 
	{

		PomClass obj=new PomClass();
		
		obj.url(driver);
		Thread.sleep(2000);
		obj.loginButton(driver);
		Thread.sleep(2000);
		obj.enterEmail(driver,email );
		Thread.sleep(2000);
		obj.enterPassword(driver, pwd);
		Thread.sleep(2000);
		obj.clickOnLoginButton(driver);
		Thread.sleep(8000);
		obj.clickOnLogOutButton(driver);
		Thread.sleep(2000);
	}

	@DataProvider
	public Object[][] dp() 
	{
		return new Object[][] 
				{
			new Object[] { "pooja2468@gmail.com", "pooja1234"},
			new Object[] { "pooja1234@gmail.com", "pooja2468"},
			new Object[] { "pooja2468@gmail.com", "pooja1234"},
			new Object[] { "pooja1234@gmail.com", "pooja2468"},
			new Object[] { "pooja2468@gmail.com", "pooja1234"},
			new Object[] { "pooja1234@gmail.com", "pooja2468"},
			
				};
	}
	

	@AfterTest
	public void tearUp() 
	{
       driver.close();
	}

}
