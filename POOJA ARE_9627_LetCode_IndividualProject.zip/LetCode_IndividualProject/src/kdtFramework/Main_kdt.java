package kdtFramework;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class Main_kdt 
{

	public static void main(String[] args) throws Exception 
	{

		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver\\chromedriver.exe");
		WebDriver driver =new ChromeDriver();
		//create object of readData
		ReadData r= new ReadData();
		r.readExcelData(driver);

	}

}
