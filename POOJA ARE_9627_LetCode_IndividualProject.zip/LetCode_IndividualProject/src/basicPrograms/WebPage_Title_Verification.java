package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebPage_Title_Verification
{

	public static void main(String[] args) throws InterruptedException 
	{
		System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		driver.get("https://letcode.in/");
		
		
		//Task 1: Title verification:
		String acceptedTitle="LetCode with Koushik";
		String actualTitle=driver.getTitle();
		
		if(actualTitle.equals(acceptedTitle))
		{
			System.out.println("Title Verification passed. ");
		}
		else
		{
			System.out.println("Title Verification failed. ");
		}
		
		driver.close();
	}

}

		
	


