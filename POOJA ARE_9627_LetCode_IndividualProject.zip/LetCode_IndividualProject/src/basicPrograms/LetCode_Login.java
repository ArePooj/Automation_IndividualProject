package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class LetCode_Login 
{
	public static void main(String[] args) throws Exception
	   {
		   System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver\\chromedriver.exe");
	       WebDriver driver=new ChromeDriver();
	       driver.get("https://letcode.in/");
	       Thread.sleep(2000);
	       driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
		   Thread.sleep(2000);
		   driver.findElement(By.linkText("Log in")).click();
		   Thread.sleep(2000);
		   driver.findElement(By.xpath("//input[@name='email']")).sendKeys("pooja2468@gmail.com");
		   Thread.sleep(2000);
		   driver.findElement(By.xpath("//input[@name='password']")).sendKeys("pooja1234");
		   Thread.sleep(2000);
		   driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
		   Thread.sleep(2000);
		   driver.close();
		   
	   }
}
