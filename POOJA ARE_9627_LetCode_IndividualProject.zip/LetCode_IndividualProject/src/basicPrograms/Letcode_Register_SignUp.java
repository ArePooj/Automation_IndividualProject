package basicPrograms;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Letcode_Register_SignUp 
{
   public static void main(String[] args) throws Exception
   {
	   System.setProperty("webdriver.chrome.driver", ".\\BrowserExtension\\chromedriver\\chromedriver.exe");
       WebDriver driver=new ChromeDriver();
       driver.get("https://letcode.in/");
       Thread.sleep(2000);
       driver.manage().window().maximize();
	   driver.manage().deleteAllCookies();
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[2]/div/div/a[1]")).click();
	   Thread.sleep(2000);
	   driver.findElement(By.id("name")).sendKeys("Pooja");
	   Thread.sleep(2000);
	   driver.findElement(By.id("email")).sendKeys("pooja2468@gmail.com");
	   Thread.sleep(2000);
	   driver.findElement(By.id("pass")).sendKeys("pooja1234");
	   Thread.sleep(2000);
	   driver.findElement(By.xpath("//button[@class='button is-primary']")).click();
	   Thread.sleep(2000);
	   driver.close();
	   
   }
}
