package basicPrograms;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mousehover
{

	public static void main(String[] args) throws Exception 
	{
	
		System.setProperty("webdriver.chrome.driver","C:\\Users\\arech\\OneDrive\\Desktop\\Automation Testing\\Browser Extension\\chromedriver\\chromedriver.exe");
        WebDriver driver=new ChromeDriver();
        driver.get("https://letcode.in/");
        Thread.sleep(2000);
        driver.manage().window().maximize();
        
        driver.manage().deleteAllCookies();
        driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/a")).click();
        Actions a = new Actions(driver);
        List<WebElement> ls=driver.findElements(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/div/a"));
        int size= ls.size();
        System.out.println(size);
        for(int i=1;i<=size;i++) 
        {
			//wait
			Thread.sleep(2000);
			System.out.println(driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/div/a["+i+"]")).getText());
			a.moveToElement(driver.findElement(By.xpath("/html/body/app-root/app-header/nav/div/div[2]/div[1]/div[1]/div/a["+i+"]"))).click().perform();
		}
        driver.close();
	}  
	

}
